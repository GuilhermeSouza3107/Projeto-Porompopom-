# curriculo.py

import dados

curriculo = f"""
================== CURRÍCULO PROFISSIONAL ==================

Nome: {dados.nome}
CPF: {dados.cpf}
Telefone: {dados.telefone}
Email: {dados.email}
Endereço: {dados.endereco}

Objetivo:
{dados.objetivo}

Sobre mim:
{dados.descricao}

Experiência profissional:
Última experiência: {dados.ultima_exp}
Função exercida: {dados.funcao}
Tempo trabalhado: {dados.tempo}

Outras experiências:
{dados.outras_exp}

Habilidades:
{dados.habilidades}

Formação:
{dados.formacao}

Disponibilidade:
{dados.disponibilidade}

================== FIM ==================
"""

with open("curriculo.txt", "w", encoding="utf-8") as arq:
    arq.write(curriculo)

print("Currículo criado no arquivo curriculo.txt!")
