nome = input("Nome completo: ")
cpf = input("CPF: ")
telefone = input("Telefone: ")
email = input("E-mail: ")
endereco = input("Endereço: ")

objetivo = input("Objetivo profissional: ")
descricao = input("Sobre mim: ")

ultima_exp = input("Última experiência: ")
funcao = input("Função exercida: ")
tempo = input("Tempo de trabalho: ")
outras_exp = input("Outras experiências relevantes: ")

habilidades = input("Habilidades: ")
formacao = input("Formação: ")
disponibilidade = input("Disponibilidade: ")

with open("dados.py", "w", encoding="utf-8") as arq:
    arq.write(f'''
nome = "{nome}"
cpf = "{cpf}"
telefone = "{telefone}"
email = "{email}"
endereco = "{endereco}"

objetivo = "{objetivo}"
descricao = "{descricao}"

ultima_exp = "{ultima_exp}"
funcao = "{funcao}"
tempo = "{tempo}"
outras_exp = "{outras_exp}"

habilidades = "{habilidades}"
formacao = "{formacao}"
disponibilidade = "{disponibilidade}"
''')