# curriculo.py

import dados

curriculo = f"""
================== CURRÍCULO PROFISSIONAL ==================

Nome: {dados.nome}
CPF: {dados.cpf}
Telefone: {dados.telefone}
Email: {dados.email}
Endereço: {dados.endereco}

Objetivo:
{dados.objetivo}

Sobre mim:
{dados.descricao}

Experiência profissional:
Última experiência: {dados.ultima_exp}
Função exercida: {dados.funcao}
Tempo trabalhado: {dados.tempo}

Outras experiências:
{dados.outras_exp}

Habilidades:
{dados.habilidades}

Formação:
{dados.formacao}

Disponibilidade:
{dados.disponibilidade}

================== FIM ==================
"""

with open("curriculo.txt", "w", encoding="utf-8") as arq:
    arq.write(curriculo)

from reportlab.pdfgen import canvas

pdf = canvas.Canvas("curriculo.pdf")
texto = pdf.beginText(40, 800)
texto.setFont("Helvetica", 11)

for linha in curriculo.split("\n"):
    texto.textLine(linha)

pdf.drawText(texto)
pdf.save()

print("Currículo também criado como curriculo.pdf!")
